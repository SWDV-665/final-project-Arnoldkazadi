
export class Comment{
    id: string;
    postId: string;
    message: string;
    date: Date;
    authorId: string; //user id
    authorName: string; 
}