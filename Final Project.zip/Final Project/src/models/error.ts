export class Error{
    pageName?: string
    error: string
    userId: string
    eventId?: string
    date: Date
    extraInfo?: string
}