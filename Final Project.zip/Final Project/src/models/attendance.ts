import { DateTime } from "ionic-angular";
import { User } from "./user";

export class AttendanceRecord{
    id: string;
    date: Date;
    userId: string;
    userName: string;    
}