export class User{
    id: string  // auth uid
    name: string
    email: string
}